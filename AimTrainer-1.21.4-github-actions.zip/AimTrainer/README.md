# AimTrainer — Minecraft 1.21.4 (Fabric)

A small client-side practice HUD mod. Hotkey **H** toggles the HUD.

## Build
Requires JDK 21 and internet access to download Gradle/Fabric dependencies.

On Linux/macOS:
```bash
gradle build
```

On Windows:
```bat
gradle build
```

The resulting mod jar is expected at `build/libs/AimTrainer-1.21.4-1.0.0.jar`.

## Current scope
This starter implementation includes a client initializer, H-key toggle, and practice HUD. It does not automatically aim at players or modify combat input.
